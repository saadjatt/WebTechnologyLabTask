function showChatBox(name){

document.getElementById("chatbox").style.display = "inline-block";
document.getElementById("friendName").innerHTML=name;
document.getElementById("msg").innerHTML="Hey "+name+" ! How are you?";
}
function closeChatBox() {
document.getElementById("chatbox").style.display = "none";

}