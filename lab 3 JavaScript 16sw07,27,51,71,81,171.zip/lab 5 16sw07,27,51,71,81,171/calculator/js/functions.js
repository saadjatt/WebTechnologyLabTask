var num1;
var num2;
var optr;
var result;
var dot=false;
function btnClick(num) {

	if(dot==false){
        if(num=="."){
		if(document.getElementById("display").value==""){

			document.getElementById("display").value+="0"+num;	

		}
		else{
			document.getElementById("display").value+=num;

		}}
	}
	if(num=="."){
		dot=true;
	}
	else{
		document.getElementById("display").value+=num;

	}

}
function operator(opr) {

	num1=parseFloat(document.getElementById("display").value);
	optr=opr;
	document.getElementById("display").value=""

}
function showResult() {
	num2=parseFloat(document.getElementById("display").value);

	if(optr=="+"){
		result=parseFloat(num1+num2);
	}
	else if(optr=="-"){
		result=parseFloat(num1-num2);
	}
	else if(optr=="/"){
		result=parseFloat(num1/num2);
	}
	else if(optr=="*"){
		result=parseFloat(num1*num2);
	}
	document.getElementById("display").value=result;
num1=parseFloat(document.getElementById("display").value);
}