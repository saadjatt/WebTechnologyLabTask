var images=["img/1.jpg","img/2.jpg","img/3.jpg","img/4.jpg","img/5.jpg"];
	var status=0;
     document.getElementById("imgBox").src=images[status];

	function nextImage() {
		status++;
		if(!(status<images.length)){
		status=0;
}

     document.getElementById("imgBox").src=images[status];
}

	function previousImage() {
		status--;

	if((status<=0)){
	status=4;

	}
        document.getElementById("imgBox").src=images[status];

	}