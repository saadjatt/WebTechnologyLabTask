<?php






$div_by_four =range(200, 250,4);

foreach ($div_by_four as $value) {
	# code...
	echo "$value <br/>";
}

?>