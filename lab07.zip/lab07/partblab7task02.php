<?php


$numbers = array( 1, 2, 3, 4, 5);


array_push($numbers,"@","#");

array_pop($numbers);


foreach ($numbers as $value){

	echo "$value";
}

?>