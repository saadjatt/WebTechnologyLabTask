<?php


$x=0;

while($x<=10){

	if($x%2==0){
		echo " ".$x;
	}
    if($x==10){
    	goto end;
    }
	$x++;
}

end:
echo "<br>";
$y=0;
while($y<10){

    if($y%2==1){
    	echo " ".$y;
}
$y++;
}


?>