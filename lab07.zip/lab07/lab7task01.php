<?php

$var=1;

while($var<=50){

    if($var%3!=0 && $var%5!=0){
		echo "<br>",$var;
	}
	else if($var%3==0 && $var%5==0){
	
		echo "<br>StarStruck";
	}
    else if($var%3==0){
    
	echo "<br>star";
	}
	else if($var%5==0){
		
     echo "<br>Struck";
	}
	
    
	
	 $var++;
}



?>