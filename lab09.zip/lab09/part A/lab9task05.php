<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('#Button').on("click",function() {
         $("#ul").css("display","block");
    });
  });
</script>
<style type="text/css">
	
	#ul{
		display: none;
	}
</style>
</head>
<body>
	<Button name="Button" id="Button"> Click me to view list </Button><br><br>
<div id = "ul">
<ul >
	<li>16SW07</li>
	<li>16SW51</li>
	<li>16SW27</li>
	<li>16SW81</li>
	<li>16SW71</li>
	<li>16SW171</li>
</ul>
</div>
</body>
</html>