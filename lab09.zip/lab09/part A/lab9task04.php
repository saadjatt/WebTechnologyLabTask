<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('.Name').keypress(function(key) {
        return false;
    });
  });
</script>
</head>
<body>
	
Enter Name:- <input type="text" name="Fname" placeholder="enter name" class = "Name">
<br><br>	
Enter RollNo:- <input type="text" name="Mname" placeholder="enter RollNo">
<br><br>	
</body>
</html>