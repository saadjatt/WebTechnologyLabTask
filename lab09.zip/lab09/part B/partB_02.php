<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AjaxTask2</title>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">

    function addCombo() {
    var textb = document.getElementById("txtCombo");
    var combo = document.getElementById("combo");
    
    var option = document.createElement("option");
    option.text = textb.value;
    option.value = textb.value;
    try {
        combo.add(option, null); //Standard 
    }catch(error) {
        combo.add(option); // IE only
    }
    textb.value = "";
}

$(document).ready(function(){
    $("select.country").change(function(){
        var selectedCountry = $(".country option:selected").val();
        $.ajax({
            type: "POST",
            url: "ajaxrequest/ajax.part2.php",
            data: { country : selectedCountry } 
        }).done(function(data){
            $("#r").html(data);
        });
    });
});

</script>


</head>
<body>
<h2>Please Only Enter</h2>
<ul>
    <li>Pakistan</li>
    <li>India</li>
</ul>
<hr>
<hr>

<div>

   
            <h3>Enter Country:</h3>
            <input type="text" name="txtCombo" id="txtCombo"/>
            <input id="b" type="button" value="Add" onclick="addCombo()">
         

            <h3>Countries Name:</h3>
                <select  name="combo" id="combo" class="country">
                <option>Select</option>
            </select>
        </div>
        <div id="r">
        </div>    







</body> 
</html>