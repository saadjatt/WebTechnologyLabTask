<?php

echo "Thanks for your feedback..";
?>