<?php

$x = 10;
$y = 5;

echo "before swapping, the variables are <br>x = ",$x;
echo "<br>y = ",$y;
 $x = $x + $y;  
 $y = $x - $y;  
 $x = $x - $y; 

echo "<br>After swapping, the variables are <br>x = ",$x;
echo "<br>y = ",$y;




?>