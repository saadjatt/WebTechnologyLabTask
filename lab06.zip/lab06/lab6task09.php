<?php


echo "<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table border=2px solid black> 
<tr>
	<td>Salary of Mr.A is </td>	
	<td>1000$</td>
</tr>
<tr>
	<td>Salary of Mr.B is </td>	
	<td>1200$</td>
</tr>
<tr>
	<td>Salary of Mr.C is </td>	
	<td>1400$</td>
</tr>
</table>
</body>
</html>";


?>