<?php


echo "The user name is ",get_current_user();
echo "<br>The current directory where the file is ",getenv('DOCUMENT_ROOT');
echo  "<br>The System is ",php_uname();

?>