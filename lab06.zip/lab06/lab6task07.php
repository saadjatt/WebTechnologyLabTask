<?php

$x = "http://sw.muet.edu.pk/faculty/cvs/sample.pdf";


echo "<br>Scheme : ",substr(str_replace("/","",$x), 0,4);
echo "<br>Host : www.",substr(str_replace("/","",$x), 8,11);
echo "<br> path : ",substr($x, 21,25);
?>