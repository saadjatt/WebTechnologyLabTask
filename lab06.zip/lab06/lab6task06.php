<?php


$x = 50;

$a  = $x>30 ? true:false;
$b  = $x>20 ? true:false;
$c  = $x>10 ? true:false;
echo "The number is x = ",$x;
if($a==1){
echo "<br>The number is greater than 30";


}
if($b==1){
echo "<br>The number is greater than 20";
}
if($c==1){
echo "<br>The number is greater than 10";
}


?>