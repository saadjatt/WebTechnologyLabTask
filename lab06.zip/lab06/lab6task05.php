<?php


echo "Tomorrow I’ll learn something new.
<br>This is a bad command: del c:\*.*\$.
";


?>