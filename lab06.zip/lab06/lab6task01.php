<?php
 
 echo PHPinfo();

?>