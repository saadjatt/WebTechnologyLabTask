<?php

$note="You cannot overload PHP functions. Function signatures are based only on their names and do not include argument lists, so you cannot have two functions with the same name.
<br>
In my case I use <b>func_num_args()</b> and <b>func_get_arg()</b> function to get the arguments passed, and use them normally.
<br>
<br>
For example:";
echo "$note";

function sum() {
	$total=0;
    for ($i = 0; $i < func_num_args(); $i++) {
        $total+=func_get_arg($i);
    }

    return $total;
}

function sub() {
	$total=func_get_arg(0);
    for ($i = 1; $i < func_num_args(); $i++) {
        $total=($total-func_get_arg($i));
    }

    return $total;
}


function mul() {
	$total=1;
    for ($i = 0; $i < func_num_args(); $i++) {
        $total=($total*func_get_arg($i));
    }

    return $total;
}

function div() {
	$total=func_get_arg(0);
    for ($i = 1; $i < func_num_args(); $i++) {
        $total=($total/func_get_arg($i));
    }

    return $total;
}

echo "<hr><h1>SUM</h1><br>";
echo  "1 + 8 = ".sum(1,8) . "<br>";
echo  "5 + 1 + 8 = ".sum(5,1,8) . "<br>";
//echo "7 + 1 + 4 = " . sum(7,1,4) . "<br>";


echo "<hr><h1>SUBTRACT</h1><br>";
echo  "1 - 8 = ".sub(1,8) . "<br>";
echo  "5 - 1 - 8 = ".sub(5,1,8) . "<br>";


echo "<hr><h1>MULTIPLY</h1><br>";
echo  "1 X 8 = ".mul(1,8) . "<br>";
echo  "5 X 1 X 8 = ".mul(5,1,8) . "<br>";


echo "<hr><h1>DIVISION</h1><br>";
echo  "8 / 1 = ".div(8,1) . "<br>";
echo  "10 / 2 / 5 = ".div(10,2,5) . "<br>";



?>
