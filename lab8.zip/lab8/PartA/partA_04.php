<?php

$note ="YES.. you can
declare a variadic function that takes in a variable number of arguments. You would use <b>func_num_args()</b> and <b>func_get_arg()</b> to get the arguments passed, and use them normally.
";

echo "$note";



function sum() {
	$total=0;
    for ($i = 0; $i < func_num_args(); $i++) {
        $total+=func_get_arg($i);
    }

    return $total;
}
//echo sum(2,2);
echo "<img src='04.jpg' />";


?>