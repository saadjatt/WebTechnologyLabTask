<?php

if (isset($_GET['sbt'])){

	$number=$_GET['number'];
	factorial($number);
}



function factorial($number)
{
	# code...
	$fact=1;
	for ($i=$number; $i >0 ; $i--) { 
		# code...
		$fact*=$i;
	}

	echo "<h1>Factorial: $fact</h1>";
	
}

//1*1




?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form method="Get">
		<input type="number" name="number">
		<input type="submit" name="sbt">
	</form>

</body>
</html>