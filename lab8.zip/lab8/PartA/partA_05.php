<?php  
function armstrongCheck($number){ 
    $sum = 0;   
    $x = $number;   
    while($x != 0)   
    {   
        $rem = $x % 10;

        $sum = $sum + $rem*$rem*$rem;   
        $x = $x / 10;   
    }   
     
    if ($number == $sum){

        return true;    
    }
    else{

return false;     
}
} 
  
$number = 153; 
$flag = armstrongCheck($number);
//echo "$flag"; 
if ($flag) 
    echo $number." is ARMSTRONG "; 
else
    echo $number." is not ARMSTRONG"; 
?> 