<!DOCTYPE html>
<html>
<head>
	<title></title>

	<?php
$myfile = fopen("test.txt", "a+ ") or die("Unable to open file!");
$txt= fread($myfile,filesize("test.txt"));
fread($myfile,filesize("test.txt"));
echo "<H1>Before</H1>";
echo $txt;
$rollNum = " My roll num is 16sw81";
fwrite($myfile, "\n".$rollNum);
fclose($myfile);
echo "<H1>After</H1>";
$lines=file("test.txt");
$text=implode($lines);
echo $text;
?>
</head>
<body>
</body>
</html>