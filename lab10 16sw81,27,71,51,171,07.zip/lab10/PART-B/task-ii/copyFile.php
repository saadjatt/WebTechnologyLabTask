<?php 

 copy("test.txt","target.txt");
echo "test.txt files is copied as target.txt";

 ?>