<!DOCTYPE html>
<html>
<head>
	<title></title>

	<?php
$myfile = fopen("test.txt", "r") or die("Unable to open file!");
$txt= fread($myfile,filesize("test.txt"));
echo $txt;

fclose($myfile);

?>
</head>
<body>
</body>
</html>