<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php 
    if(isset($_GET['deleteFile'])){
    header("Location:DeleteFile.php");

    }
if(isset($_GET['readFile'])){
    header("Location:readFile.php");
    }

    if(isset($_GET['copyFile'])){
    header("Location:copyFile.php");
    }
    if(isset($_GET['renameFile'])){
    header("Location:renameFile.php");
    }
    
	 ?>
</head>
<body>
<form  method="get">
	<button name="readFile" type="submit">Read File</button>
	<button name="deleteFile" type="submit">Delete File</button>
	<button name="copyFile" type="submit">Copy File</button>
    <button name="renameFile" type="submit">Rename Folder</button>
</form>

</body>
</html>