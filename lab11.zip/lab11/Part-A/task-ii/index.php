<?php 


session_start()





 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<header>
	<img src="img/logo.png">
	<h1>Surkhi</h1>
     <form action="view-cart.php">
	<button style="background-color:  #fdf4f49c; padding: 10px; border-radius: 10px;">View Cart </button></form>
</header>
<marquee>
<section class="ads">
	<center>
		<img src="img/colors.jpg" >
		<h4>Sale Sale Sale</h4>
	</center>
</section>
</marquee>
<section>
	<div class="one">
		<img src="img/one.jpg" >
		<h3>Rs.100</h3>
		<div class="buy">
			<?php 
            if(isset($_GET['Surkhi'])){
            	 $name="surkhi";
            	$_SESSION['names'] = array();
		array_push($_SESSION['names'],$name);
            }
			 ?>
            
		 <form method="get"><button type="submit" name="Surkhi">Add to Cart</button></form>
		</div>
	</div>
	<div class="one">
		<img src="img/one.jpg" >
		<h3> Rs.200</h3>
		<div class="buy">
		<a href="details.html">Add to Cart</a>
		</div>
	</div>
	<div class="one">
		<img src="img/two.jpg" >
		<h3>Rs. <del>400</del> 300</h3>
		<div class="buy">
		<a href="details.html">Add to Cart</a>
		</div>
	</div>
	<div class="one">
		<img src="img/8.jpg" >
		<h3>Rs. <del>500</del> 200</h3>
		<div class="buy">
		<a href="details.html">Add to Cart</a>
		</div>
	</div>

	<div class="one">
		<img src="img/five.jpg" >
		<h3>Rs. <del>500</del> 200</h3>
		<div class="buy">
		<a href="details.html">Add to Cart</a>
		</div>
	</div>

		<div class="one">
		<img src="img/two.jpg" >
		<h3>Rs. <del>500</del> 200</h3>
		<div class="buy">
		<a href="details.html">Add to Cart</a>
		</div>
	</div>
</section>
<footer>
	
	<h3>Copyrights @ massiha 2018</h3>
</footer>
</body>
</html>